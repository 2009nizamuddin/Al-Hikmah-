package com.alhikmah.live

import android.content.ComponentName
import android.os.Bundle
import android.view.WindowManager
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.alhikmah.live.databinding.ActivityPlayerBinding
import com.google.common.util.concurrent.MoreExecutors

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var controller: MediaController? = null
    private var isMuted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep the screen on while actively listening in the foreground.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.playerToolbar.setNavigationOnClickListener { finish() }

        connectToPlaybackService()
        setupControls()
    }

    private fun connectToPlaybackService() {
        val sessionToken = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
            updatePlayPauseIcon()
        }, MoreExecutors.directExecutor())
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayPauseIcon()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val isLive = playbackState == Player.STATE_READY || playbackState == Player.STATE_BUFFERING
            binding.playerStatusDot.setBackgroundResource(
                if (isLive) R.drawable.dot_live else R.drawable.dot_offline
            )
            binding.playerStatusText.text = getString(
                if (isLive) R.string.status_live else R.string.status_offline
            )
        }
    }

    private fun setupControls() {
        binding.playPauseButton.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.isPlaying) c.pause() else c.play()
        }

        binding.muteButton.setOnClickListener {
            isMuted = !isMuted
            controller?.volume = if (isMuted) 0f else (binding.volumeSeekBar.progress / 100f)
            binding.muteButton.setImageResource(
                if (isMuted) R.drawable.ic_volume_off else R.drawable.ic_volume_up
            )
        }

        binding.volumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (!isMuted) controller?.volume = progress / 100f
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        // "Fullscreen" for an audio stream just locks to landscape for a
        // larger now-playing view — there's no video surface to expand.
        binding.fullscreenButton.setOnClickListener {
            requestedOrientation = if (requestedOrientation ==
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            ) {
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            } else {
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
        }
    }

    private fun updatePlayPauseIcon() {
        val isPlaying = controller?.isPlaying == true
        binding.playPauseButton.setImageResource(
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        super.onDestroy()
    }
}
