package com.alhikmah.live

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.alhikmah.live.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        requestNotificationPermissionIfNeeded()
        setupWebView()
        binding.nativePlayerButton.setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }

        pollLiveStatusInForeground()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                binding.webProgress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                binding.webProgress.visibility = View.GONE
            }
        }

        // Smart auto-detect: WebChromeClient gets called by the page's own
        // player when it enters/exits HTML5 fullscreen — we mirror that into
        // native fullscreen and hide the app chrome while it's active.
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback

                binding.fullscreenContainer.visibility = View.VISIBLE
                binding.fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                )
                binding.webView.visibility = View.GONE
                supportActionBar?.hide()
            }

            override fun onHideCustomView() {
                binding.fullscreenContainer.visibility = View.GONE
                binding.fullscreenContainer.removeView(customView)
                customView = null
                customViewCallback?.onCustomViewHidden()
                binding.webView.visibility = View.VISIBLE
                supportActionBar?.show()
            }
        }

        webView.loadUrl(Config.WEB_LIVE_PAGE_URL)
    }

    /** Lightweight foreground poll purely to keep the status pill fresh while the screen is open. */
    private fun pollLiveStatusInForeground() {
        lifecycleScope.launch {
            while (isActive) {
                val isLive = withContext(Dispatchers.IO) { checkIsLiveSafely() }
                updateStatusUi(isLive)
                delay(60_000L) // refresh every minute while the app is in the foreground
            }
        }
    }

    private fun checkIsLiveSafely(): Boolean = try {
        val request = Request.Builder().url(Config.STATUS_CHECK_URL).build()
        httpClient.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty().lowercase()
            Config.LIVE_MARKERS.any { body.contains(it.lowercase()) }
        }
    } catch (e: Exception) {
        false
    }

    private fun updateStatusUi(isLive: Boolean) {
        binding.statusDot.setBackgroundResource(if (isLive) R.drawable.dot_live else R.drawable.dot_offline)
        binding.statusText.text = getString(if (isLive) R.string.status_live else R.string.status_offline)
    }

    override fun onBackPressed() {
        if (customView != null) {
            binding.webView.webChromeClient?.onHideCustomView()
        } else if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        binding.webView.destroy()
        super.onDestroy()
    }
}
