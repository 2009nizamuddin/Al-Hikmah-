package com.alhikmah.live

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class AlHikmahApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        scheduleLiveStatusPolling()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(
                Config.NOTIF_CHANNEL_LIVE,
                getString(R.string.notif_channel_live_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = getString(R.string.notif_channel_live_desc) }
        )

        nm.createNotificationChannel(
            NotificationChannel(
                Config.NOTIF_CHANNEL_PLAYBACK,
                getString(R.string.notif_channel_playback_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = getString(R.string.notif_channel_playback_desc) }
        )
    }

    private fun scheduleLiveStatusPolling() {
        val request = PeriodicWorkRequestBuilder<LiveStatusWorker>(
            Config.POLL_INTERVAL_MINUTES, TimeUnit.MINUTES
        ).build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "live_status_poll",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
