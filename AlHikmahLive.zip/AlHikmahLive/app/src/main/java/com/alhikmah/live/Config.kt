package com.alhikmah.live

/**
 * Everything a maintainer needs to tune when al-hikmah.net changes its page
 * structure or streaming provider lives here.
 *
 * HOW TO FIND THE REAL VALUES:
 * 1. Open https://live.al-hikmah.net/ in Chrome on desktop.
 * 2. Open DevTools (F12) -> Network tab -> filter by "Media" (or "All").
 * 3. Reload the page. Look for a continuously-loading request of type
 *    audio/mpeg, audio/aac, or a .m3u8 playlist — that request's URL is
 *    your DIRECT_STREAM_URL below. It will likely point at
 *    stream.sm40.com with a specific port/mount, e.g.
 *    "https://stream.sm40.com:PORT/;stream.mp3" (Shoutcast/Icecast style).
 * 4. To detect "live vs offline", view-source the page and find an element
 *    or script variable that flips when the stream is active (e.g. a
 *    "LIVE" badge, or an Icecast /status-json.xsl endpoint if the host
 *    exposes one — try https://stream.sm40.com:PORT/status-json.xsl).
 */
object Config {

    /** The page users see embedded in the in-app WebView. */
    const val WEB_LIVE_PAGE_URL = "https://live.al-hikmah.net/"

    /**
     * Direct audio stream URL for the native ExoPlayer path.
     * PLACEHOLDER — replace after inspecting the network tab as described above.
     */
    const val DIRECT_STREAM_URL = "https://stream.sm40.com/;stream.mp3"

    /**
     * URL polled in the background to determine live/offline status.
     * If the streaming host exposes an Icecast status-json.xsl endpoint,
     * point this at that instead — it's far more reliable than scraping HTML.
     */
    const val STATUS_CHECK_URL = "https://live.al-hikmah.net/"

    /**
     * Very simple heuristic: if the fetched HTML/JSON body contains any of
     * these (case-insensitive), we consider the broadcast live. Tune this
     * once you've viewed the actual page/endpoint response.
     */
    val LIVE_MARKERS = listOf("\"live\":true", "is-live", ">LIVE<", "streamstatus\":1")

    /** How often WorkManager checks for a live broadcast, in minutes. 15 is the OS minimum. */
    const val POLL_INTERVAL_MINUTES = 15L

    const val NOTIF_CHANNEL_LIVE = "live_alerts"
    const val NOTIF_CHANNEL_PLAYBACK = "playback_controls"
    const val NOTIF_ID_LIVE_ALERT = 1001
}
