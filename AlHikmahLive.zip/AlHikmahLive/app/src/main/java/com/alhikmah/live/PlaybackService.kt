package com.alhikmah.live

import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the single ExoPlayer instance used for native audio playback and
 * exposes it through a MediaSession. Media3 automatically renders the
 * system media notification (play/pause, stop) and keeps this service in
 * the foreground while something is playing, so no manual
 * NotificationCompat wiring is needed here.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(Config.DIRECT_STREAM_URL))
            prepare()
        }
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
