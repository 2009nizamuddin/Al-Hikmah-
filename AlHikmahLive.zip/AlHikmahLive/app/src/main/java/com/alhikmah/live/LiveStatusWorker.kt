package com.alhikmah.live

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Runs roughly every [Config.POLL_INTERVAL_MINUTES] minutes via WorkManager
 * (survives app kill and device reboot once rescheduled by BootReceiver).
 * Fetches [Config.STATUS_CHECK_URL], checks for [Config.LIVE_MARKERS], and
 * — only on the OFFLINE -> LIVE transition — sends a notification.
 */
class LiveStatusWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val isLive = checkIsLive()
            val prefs = applicationContext.getSharedPreferences("live_state", Context.MODE_PRIVATE)
            val wasLive = prefs.getBoolean("was_live", false)

            prefs.edit().putBoolean("was_live", isLive).apply()

            if (isLive && !wasLive) {
                NotificationHelper.showLiveNotification(applicationContext)
            }
            Result.success()
        } catch (e: Exception) {
            // Network hiccup — don't burn retries aggressively, just wait for the next cycle.
            Result.success()
        }
    }

    private fun checkIsLive(): Boolean {
        val request = Request.Builder().url(Config.STATUS_CHECK_URL).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return false
            val body = response.body?.string().orEmpty().lowercase()
            return Config.LIVE_MARKERS.any { marker -> body.contains(marker.lowercase()) }
        }
    }
}
