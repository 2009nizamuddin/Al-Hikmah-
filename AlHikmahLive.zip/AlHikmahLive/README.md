# Al Hikmah Live — Android App

An unofficial companion app that embeds the live broadcast from **al-hikmah.net**
(Rajarbag Shareef), with an Islamic green/white theme, live/offline status,
background live-check polling, push notifications, and both a WebView player
and a native audio (ExoPlayer/Media3) player.

> **Note:** al-hikmah.net's live broadcast is **audio**, not video (it streams
> via an Icecast/Shoutcast-style server at `stream.sm40.com`). There is also
> already an official Play Store app (`com.rajarbagshareef.alhikmah`) — worth
> checking before shipping a duplicate.

## 1. Before you build: fill in two placeholders

Open `app/src/main/java/com/alhikmah/live/Config.kt`. Two values are
placeholders because they must be reverse-engineered from the live site,
which changes without notice and isn't something that can be hardcoded
reliably from outside:

1. **`DIRECT_STREAM_URL`** — the direct audio stream URL, used by the native
   ExoPlayer screen.
2. **`STATUS_CHECK_URL`** / **`LIVE_MARKERS`** — what the background poller
   fetches and what text/JSON pattern in the response means "currently live".

**How to find them:**
- Open `https://live.al-hikmah.net/` in Chrome desktop → DevTools (F12) →
  Network tab → filter to "Media" → reload the page. The continuously
  loading request (type `audio/mpeg`, `audio/aac`, or `.m3u8`) is your
  `DIRECT_STREAM_URL`.
- If the host is Icecast, it often exposes `https://<host>:<port>/status-json.xsl`,
  which returns JSON you can poll directly and reliably instead of scraping HTML.
- View-source the page for whatever marks "on air" (a `LIVE` badge class,
  a JS variable, etc.) and adjust `LIVE_MARKERS` to match.

If the stream turns out to be plain `http://` rather than `https://`, no
extra work is needed — `network_security_config.xml` already whitelists
cleartext traffic for `sm40.com` and `al-hikmah.net`.

## 2. Project structure

```
AlHikmahLive/
├── build.gradle                     (project-level)
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle                 (dependencies)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/alhikmah/live/
        │   ├── AlHikmahApp.kt        Application: notif channels + schedules polling
        │   ├── Config.kt             All tunable constants (see step 1)
        │   ├── SplashActivity.kt     Splash screen → fades into MainActivity
        │   ├── MainActivity.kt       WebView player + live status pill
        │   ├── PlayerActivity.kt     Native ExoPlayer audio screen + controls
        │   ├── PlaybackService.kt    Media3 MediaSessionService (background audio)
        │   ├── LiveStatusWorker.kt   WorkManager periodic live-check + notification
        │   ├── NotificationHelper.kt Builds/shows the "now live" notification
        │   └── BootReceiver.kt       Reschedules polling after device reboot
        └── res/
            ├── layout/               activity_splash, activity_main, activity_player
            ├── values/               colors.xml (green/white palette), strings, themes
            ├── drawable/             status dots, play/pause/volume/fullscreen icons
            └── xml/                  network_security_config.xml
```

## 3. Import into Android Studio

1. Open Android Studio → **File → New → Import Project**, and select the
   `AlHikmahLive` folder (or `File → Open` and pick the folder directly —
   Android Studio recognizes the Gradle project automatically).
2. Let Gradle sync. It will pull down AppCompat, Material, Media3/ExoPlayer,
   WorkManager, OkHttp, and Coroutines as declared in `app/build.gradle`.
3. **Launcher icons:** the manifest references `@mipmap/ic_launcher` and
   `ic_launcher_round`, which a fresh "Empty Views Activity" project template
   normally generates. If you started from this scaffold directly, right-click
   `res` → **New → Image Asset** and generate a launcher icon (green mosque/
   crescent works well with this theme) so those references resolve.
4. Fill in `Config.kt` as described in step 1.

## 4. Test it

- **Run on a device/emulator:** `Shift+F10` (Run) with a device connected
  or an emulator (API 24+) running. Grant the notification permission
  prompt on first launch (Android 13+).
- **WebView player:** confirm the live page loads in `MainActivity` and that
  tapping into the page's own player (if it has an HTML5 fullscreen button)
  correctly expands full-screen and hides the app bar, and Back exits it
  cleanly.
- **Native player:** tap "Open Audio Player" → Play should start audio
  through `PlaybackService`; check the system notification shade shows
  the media control (play/pause/stop) generated automatically by Media3.
  Background the app — audio should keep playing.
- **Live-check notification:** to test without waiting 15 minutes, in
  Android Studio's **App Inspection → Background Task Inspector** you can
  manually trigger `LiveStatusWorker`, or temporarily lower
  `Config.POLL_INTERVAL_MINUTES` for testing (note: 15 is Android's
  enforced minimum for periodic work in production).
- **Airplane mode test:** confirm the status pill correctly falls back to
  "Offline" and the app doesn't crash when the network call fails.

## 5. Build the APK automatically in the cloud (GitHub Actions — no Android Studio needed)

This project includes `.github/workflows/build-apk.yml`, which builds a
debug APK on every push and lets you download it from GitHub — no local
Android Studio install required.

**Setup (one time):**
1. Create a new repository on GitHub (public or private — Actions works
   on both; private repos on a free personal account get 2,000 free
   Actions minutes/month, which is plenty for this).
2. From inside the unzipped `AlHikmahLive` folder, push it:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
3. On GitHub, go to your repo's **Actions** tab. The "Build APK" workflow
   runs automatically on that push. Wait for the green checkmark
   (first run takes a few minutes while it downloads Gradle/SDK layers;
   later runs are faster thanks to caching).
4. Click into the finished run → scroll to **Artifacts** →
   download **AlHikmahLive-debug-apk**. It's a zip containing
   `app-debug.apk` — unzip it and it's ready to sideload onto any
   Android phone (enable "Install unknown apps" for whatever app you
   transfer it with).

**Re-running it later:** any future `git push` to `main` re-triggers a
build automatically. You can also trigger it manually anytime from
**Actions → Build APK → Run workflow** (no code change needed) — useful
right after you edit `Config.kt` with the real stream URL.

**Signed release APK (optional, needed only for Play Store or a
tamper-proof install):** the workflow has a commented-out release-build
section. To use it: generate a keystore locally
(`keytool -genkey -v -keystore release.keystore -alias alhikmah -keyalg RSA -keysize 2048 -validity 10000`),
base64-encode it, and add `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD` as **Settings → Secrets and variables →
Actions → New repository secret** in your GitHub repo, then uncomment
that section of the workflow. Until then, `assembleDebug` is what you
want — the debug APK installs fine for personal/testing use, it's just
not eligible for Play Store distribution.

## 5b. Build the APK locally instead

- **Debug APK (for sideloading/testing):**
  `Build → Build Bundle(s) / APK(s) → Build APK(s)`, or from terminal:
  ```
  ./gradlew assembleDebug
  ```
  Output: `app/build/outputs/apk/debug/app-debug.apk`

- **Release APK (signed, for distribution):**
  `Build → Generate Signed Bundle / APK` → choose **APK** → create/select a
  keystore → choose `release` build variant. Or via terminal after
  configuring a signing config in `app/build.gradle`:
  ```
  ./gradlew assembleRelease
  ```
  Output: `app/build/outputs/apk/release/app-release.apk`

## 6. Notes on permissions requested

| Permission | Why |
|---|---|
| `INTERNET` | Load the WebView page and stream audio |
| `ACCESS_NETWORK_STATE` | Avoid pointless network calls when offline |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Keep audio playing when the app is backgrounded |
| `WAKE_LOCK` | Prevent playback from stopping when the screen sleeps |
| `POST_NOTIFICATIONS` | Required on Android 13+ to show the "now live" alert and playback notification |
| `RECEIVE_BOOT_COMPLETED` | Re-arm the periodic live-check job after a reboot |
